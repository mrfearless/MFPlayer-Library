.. MFPlayer Library documentation master file

Welcome to MFPlayer Library's documentation!
==============================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:
  
   Introduction/index
   MFPlayer Functions/index
    

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
